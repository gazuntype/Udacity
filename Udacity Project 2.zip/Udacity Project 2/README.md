**Resubmission

Name: Olutade Ajiboye
Time: It took slightly over an hour to complete this project.
Likes: I liked how different lighting could completely change how the seen looked.
Challenging thing: Picking the appropriate light settings that would balance optimisation and visuals.

From changing the bake resolution, when very low, the lightmap was small and it baked quickly. But the objects didn't look nice. On increasing the baker resolution, the objects grew clearer and nicer but baking time was increased and the lightmap was larger.