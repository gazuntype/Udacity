Name: Olutade Ajiboye
Time: It took about 30 minutes to complete this project.
Likes: I liked the fact that you could test the app on runtime within the Unity Editor.
Challenging thing: Funnily enough, the most challenging thing was creating this README.md file.