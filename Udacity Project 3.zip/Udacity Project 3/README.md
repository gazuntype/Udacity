**Resubmit
Name: Olutade Ajiboye
Time: It took slightly over three hours to complete this project.
Likes: I liked how one can accomplish almost anything with the right scripts.

*Key.cs has been changed to include boolean hasKey.